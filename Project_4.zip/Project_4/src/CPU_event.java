import java.util.Random ;

public class CPU_event	// this class returns a result from a range by percentage
{
	private double	event;
	private int rangeResult;

	public CPU_event()
	{

	}

	public int get_CPU_event()
	{
		Random random__X	= new Random();	//#010 declare random object

		event = random__X.nextGaussian();
		//#020 instantiate the object and assign to: event

		if (event >= 1.645)	//#100 5% Terminated/completed
		{
			rangeResult = 1 ; 		//set to complete for 5%
		}
			else
			{
				if ((event >= 1.036) && (event < 1.645))	//#200	10% INTERRUPT
				{
					rangeResult = 2;		// Set to interrupt for 10%
				}
					else
					{
						if ((event >= 0.524) && (event < 1.036))	//#300 15% BLOCKPAGE
						{
							rangeResult = 3 ;		// set to BlockPage for 15%
						}
							else
							{
								if ((event >= 0) && (event < .524))	//#0400 20% Block I/0
								{
									rangeResult = 4 ;		// Set to I/O block for 20%
								}
									else
									{
										rangeResult = 5;		//#0500 true if event is between 51-100 other
									}
							}
					}
			}
		return rangeResult ;
	}
}