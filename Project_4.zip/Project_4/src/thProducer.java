import java.util.concurrent.LinkedBlockingQueue	;
import java.util.Collections;
import java.util.Random	;
import java.util.LinkedList ;



public class thProducer implements Runnable
{
	private LinkedBlockingQueue<PCB>	QReady	;
	private LinkedBlockingQueue<PCB>	QWait	;

	private boolean	running	;
	
	//	constructor method
	
public thProducer (LinkedBlockingQueue<PCB> qr0, LinkedBlockingQueue<PCB> qw0)
	{
		this.QReady	= qr0	;
		this.QWait	= qw0	;
		this.running	= true	;
	}
	public boolean isRunning()
	{
		return running;
	}
	@Override
	public void run()
	{
		PCB PCB_Ready;
		PCB PCB_Running;
		PCB PCB_Current = null;
		PCB PCB_prev = null;
		int base;
		int limit;
		OpenMem om = new OpenMem();
		LinkedList<PCB>QMemOpen = new LinkedList<PCB>();
		LinkedList<PCB>QMemUsed = new LinkedList<PCB>();
		int CPU_Used;
		int CPU_Max;
		Random random__X	= new Random();
		int CPU_runtime;
		int waitTime;
		int event__X ;
		CPU_event event		= new CPU_event();
		final int BLOCKIO	= 4 ;
		final int BLOCKPAGE	= 3 ;
		final int INTERRUPT	= 2 ;
		final int COMPLETED	= 1 ;
		final int mem__T = 256;
		QMemOpen.add(new PCB(mem__T));
		
		while(!QReady.isEmpty()|| !QMemUsed.isEmpty())
		{
			try
			{
				PCB_Ready = QReady.take();
			
			boolean memFound__B	= om.findOpenMem(PCB_Ready, QMemOpen, QMemUsed);

			for (PCB loopI : QMemOpen)
				System.out.printf("\n@020Open\t%s\n"	,loopI.showPCB());

			for (PCB loopI : QMemUsed)
				System.out.printf("@0200Used\t%s\n"	,loopI.showPCB());

			if (!memFound__B)	//#0160
			{
				System.out.printf("##### No Memory Available for Process:%d\tneeding:%d\n"
						,PCB_Ready.get_ID()
						,PCB_Ready.get_Limit()	);
				QReady.put(PCB_Ready);
					// skip to the next process
			}
			System.out.println("=====");

			//#0400	simulate memory free process


			//#0500 Sort the QMemUsed

			Collections.sort(QMemUsed);
			for (PCB loopI : QMemUsed)
			{
				System.out.printf("@0500 sorted Used\t%s\n", loopI.showPCB()) ;
			}

			//#0600 Defragmentation processing
			if(QMemUsed.size()==0)
			{
				continue;
			}
			PCB_Current = QMemUsed.getFirst();
			base = PCB_Current.get_memBase();
			limit = PCB_Current.get_Limit();
				if(base != 0) {
					PCB_Current.set_memBase(0);
				}
					for( int q=1; q < QMemUsed.size(); q++)
					{
						PCB_Current = QMemUsed.get(q);
						PCB_prev = QMemUsed.get(q-1);
						int CurrentBase = PCB_Current.get_memBase();
						int PrevLimit= PCB_prev.get_Limit();
						int PrevBase= PCB_prev.get_memBase();
							if((CurrentBase - 1) !=  (PrevLimit + PrevBase))
							{
								PCB_Current.set_memBase(PrevLimit + PrevBase +1);
							}
					}
							PCB_Current=QMemUsed.getLast();
							base = PCB_Current.get_memBase();
							limit= PCB_Current.get_Limit();
							PCB_Current= QMemOpen.getFirst();
							PCB_Current.set_memBase(base + limit + 1);
							int free = base + limit + 1;
							PCB_Current.set_memLimit(256 - free);
							
							//#0140 Assign the first node from QReady to Running
							PCB_Running= QMemUsed.removeFirst();
							PCB_Running.set_state("Running");
							//#0145 Set the state value to "Running"

							CPU_runtime	= random__X.nextInt(20) + 1 ;	//#0150 Get a random no. between 0 and 20

							//#0160 Tally and set the CPU used for the process
							CPU_Used = PCB_Running.get_CPU_used();// hold old CPU
							CPU_Used +=CPU_runtime;
							PCB_Running.set_CPU_used(CPU_Used);

							System.out.println("\n*****\t\t\tRunning Queue\t\t\t*****");
							System.out.println(PCB_Running.showPCB());

							//add time waiting to every node in QReady
							for( int i=0; i<QReady.size(); i++)
							{
								PCB_Current = QReady.take();
								waitTime=PCB_Current.get_timeWaiting();
								waitTime+=CPU_runtime;
								PCB_Current.set_timeWaiting(waitTime);
								QReady.put(PCB_Current);
							}

							CPU_Used= PCB_Running.get_CPU_used();//hold cpu used
							CPU_Max= PCB_Running.get_CPU_max();// hold cpu max
			
							if(CPU_Used > CPU_Max)	// compare CPU max and used to see it is done
								//#0190 IF statement for termination based on CPU Max
						{
							PCB_Running.set_state("Terminated");
							System.out.println("\n*****\t\t\tProcess Completed\t\t\t*****");
							System.out.println(PCB_Running.showPCB());

									//continue;	// iterate to the next in the WHILE loop
						}
							else {
						//#0200 Simulate the type of Block on the Process (I/O Block, Memory Paging Block, Interrupt)

						event__X	= event.get_CPU_event();
						System.out.println("CPU Event   " +event__X);

						if (event__X == COMPLETED)
						{
							PCB_Running.set_state("Terminated");
							System.out.println("\n*****\t\t\tProcess Completed\t\t\t*****CPU event*****");
							System.out.println(PCB_Running.showPCB());
						}
						else
						{
							//#230 Set the state to "Ready" from "Running"

							switch (event__X)
							{
								case INTERRUPT :
								{
									//#240 Add to QReady first
									PCB_Running.set_state("Ready");
									QReady.put(PCB_Running);

									break;
								}
								case BLOCKPAGE :
								{
									//#242 Add to QReady middle
									PCB_Running.set_state("Ready");
									QReady.put(PCB_Running);
									break;
								}
								case BLOCKIO :
								{
									//#244 Add to QWait	 last
									System.out.println("****** \t\t\tDisk Inturupt\t\t\t****** ");
									PCB_Running.set_state("Waiting");
									QWait.put(PCB_Running);
									break;
								}
								default :
								{
									//#246 Add to QReady last
									PCB_Running.set_state("Ready");
									QReady.put(PCB_Running);
									break;
								}
							}
						}

						System.out.println("\n*****\t\t\tContext Switch\t\t\t\t*****");
						//#300 print out PCB's in both QReady and QWait
							}

			}
			catch (InterruptedException e1) 
			{
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			

			
			
		}
		System.out.printf	("@@@prod\t completed\n")	;
        running = false;
	}
}
