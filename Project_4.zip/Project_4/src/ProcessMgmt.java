import java.util.concurrent.LinkedBlockingQueue;



public class ProcessMgmt
{
	@SuppressWarnings("unchecked")
	public static void main(String args[]) throws InterruptedException
	{
		LinkedBlockingQueue<PCB> QReady	= new LinkedBlockingQueue<PCB>();
		LinkedBlockingQueue<PCB> QWait	= new LinkedBlockingQueue<PCB>();
		
		thProducer	producer	= new thProducer	(QReady	,QWait	)	;
		thConsumer	consumer	= new thConsumer	(QReady	,QWait	,producer	)	;

		Thread	producerThread	= new Thread	(producer)	;
		Thread	consumerThread	= new Thread	(consumer)	;
		
		//#010	Initialization of fields and data structures	///////////////
		int QREADY__T	= 25 ;
		for (int ii=0; ii<QREADY__T; ii++)
		{
			PCB pcbMain	= new PCB();
			QReady.add(pcbMain)	;
			
			System.out.printf("\t%d: %s\n"	,ii	,pcbMain.showPCB());
		}
		producerThread.start()	;
		consumerThread.start()	;
		

		while (Thread.activeCount()>1)
		{
			for (PCB loopI : QReady)
				System.out.printf("***\tmain-0400: %s\t***\n"	,loopI.showPCB()) ;
			
			Thread.sleep(1000)	;
		}
		
		System.out.printf("@@@\tdone\t@@@\n");

	}
}