import java.util.Random;

	class node {

	    // represent difference between head position and track number
	    int distance = 0;
	    // true if track has been accessed
	    boolean accessed = false;
	}
	
public class DiskScheduling {
	
	Random r = new Random();
	int ranNum = r.nextInt(500)+1;
	int lasthead = ranNum;
	
	public void DiskInterrupt(){
		
		int arr[] = new int[10];
		
		for(int x=0; x<arr.length; x++)
		{
			ranNum = r.nextInt(500)+1;
			arr[x] = ranNum;
						
			//condition if both the number is same
			for(int inner=x; inner>0; inner--)
			{				
				if(arr[inner]== arr[x])			
					arr[inner] = r.nextInt(500)+1;			
			}			
		}// end of for loops
		System.out.print("The numbers in the Disk are: ");
		for(int x : arr)
			System.out.print(x + " ");
		System.out.println();
		
		System.out.println("The head of the Disk for SSTF: " + lasthead);
		
		shortestSeekTimeFirst(arr, lasthead);
	}// end of DiskInterrupt
	
	
	//calculate the difference of each request from the head position
	public void Difference(int array[], int head, node diff[])
	{
		for(int i = 0; i< diff.length; i++)
		{
			diff[i].distance = Math.abs(array[i] - head);
		}
		
	}// end of difference method
	
	//calcuate the minimum distance from the head node
	public int finMin(node d[])
	{
		 int index = -1, minimum = Integer.MAX_VALUE;

	        for (int i = 0; i < d.length; i++) {
	            if (!d[i].accessed && minimum > d[i].distance) {

	                minimum = d[i].distance;
	                index = i;
	            }
	        }
	        return index;
	}
	
									// the method for sstf
	
	public void shortestSeekTimeFirst(int request[], int head)
    {
    
        // create array of objects of class node
        node diff[] = new node[request.length];

        // initialize array
        for (int i = 0; i < diff.length; i++)
            diff[i] = new node();

        // count total number of seek operation
        int seek_count = 0;

        // stores sequence in which disk access is done
        int[] seek_sequence = new int[request.length + 1];

        for (int i = 0; i < request.length; i++) {

            seek_sequence[i] = head;
            Difference(request, head, diff);

            int index = finMin(diff);

            diff[index].accessed = true;

            // increase the total count
            seek_count += diff[index].distance;

            // accessed track is now new head
            head = request[index];
        }

        // for last accessed track
        seek_sequence[seek_sequence.length - 1] = head;

        System.out.println("Total number of seek operations for SSTF = " + seek_count);

        System.out.print("Seek Sequence for SSTF: ");

        // print the sequence
        for (int i = 0; i < seek_sequence.length; i++)
        {
            System.out.print(" " + seek_sequence[i]);
        }
        lasthead = seek_sequence[seek_sequence.length -1];

        System.out.println(" \n last spot of head for SSTF " + lasthead);
    }
	
	
}// end of the class
