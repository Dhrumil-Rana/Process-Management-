
	import java.util.LinkedList;

	public class OpenMem {
		public OpenMem ()
		{}
		public boolean findOpenMem	(PCB PCB_Ready, LinkedList<PCB> QMemOpen, LinkedList<PCB> QMemUsed	)
		{
			boolean memFound__B = false ;

			int memNeed = PCB_Ready.get_Limit() ;	//@0100

			for (int ii = 0; ii < QMemOpen.size(); ii ++)
			{
				PCB memOpen = QMemOpen.get(ii) ;	//@0120
				if (memOpen.get_Limit() > memNeed )	//@0200
				{
					memFound__B = true;
					int base = memOpen.get_memBase();
					int newBase = base+memNeed +1;
					memOpen.set_memBase(newBase);
					int limit = memOpen.get_Limit();
					limit = limit - memNeed;
					memOpen.set_memLimit(limit);

					PCB_Ready.set_memBase(base);
					//@0220	split the open memory	@@ QMemOpen @@


					//@0240	replace the open memory


				//	System.out.printf("@0300 Used\t%s\n"	,memUsed.showPCB());


					//@0260	allocate the used memory	@@ QMemUsed @@
						QMemUsed.add(PCB_Ready);
					//@0280	set the base for the process
						PCB_Ready.set_memBase(base);
					//@0300	push the used memory

			//		System.out.printf("@0300 Used\t%s\n"	,memUsed.showPCB());

					break ;	// exit out of the FOR loop for memory
				}
			}
			return memFound__B ;
		}
	}




